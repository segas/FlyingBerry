sudo route add default gw 192.168.8.1 eth1

sudo python /home/sgas/project_flyingberry/sensordata.py
