# GrovePi Trubleshooting Script

The scripts here are for finding the common problems with the GrovePi.

To run the test, make the complete_test.sh executable:
		sudo chmod +x complete_test.sh
and run it:
		sudo ./complete_test.sh

Choose option 5 to run all the tests. This might take a few minutes.

Once the tests are completed, a log.txt file would be created on the Desktop. Send this by email or post it on the forums. 

See more about the GrovePi at http://www.dexterindustries.com/grovepi