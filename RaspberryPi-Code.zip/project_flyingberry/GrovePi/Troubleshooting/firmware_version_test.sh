#! /bin/bash
echo ""
echo Checking for firmware version
echo =============================
sudo python /home/pi/Desktop/GrovePi/Software/Python/grove_firmware_version_check.py