## **Using Multiple GrovePi**

The instructions for using multiple GrovePi's can be found here: http://www.dexterindustries.com/GrovePi/engineering/using-multiple-grovepis-together/
### Getting Help
Need help? We [have a forum here where you can ask questions or make suggestions](http://www.google.com/url?q=http%3A%2F%2Fwww.dexterindustries.com%2FGrovePi%2Fprojects-for-the-raspberry-pi%2F&sa=D&sntz=1&usg=AFQjCNGoiMlC8E9az6mCY2piHsVCl984xg).

These files have been made available online through a [Creative Commons Attribution-ShareAlike 3.0](http://creativecommons.org/licenses/by-sa/3.0/) license.

See more at the [GrovePi Site](http://dexterindustries.com/GrovePi/)
