﻿namespace GrovePi.Sensors
{
    public enum SensorStatus
    {
        Off = 0,
        On = 1
    }
}