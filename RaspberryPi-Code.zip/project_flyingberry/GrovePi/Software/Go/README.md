# Go library for GrovePi

## Introduction
You will need to install mrmorphic hwio library
go get github.com/mrmorphic/hwio