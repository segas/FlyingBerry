GrovePi Examples for using the [Grove GPS Module](http://www.seeedstudio.com/depot/Grove-GPS-p-959.html?cPath=25_130)

*Files*:
- grove_gps_hardware_test.py : This example is for is the simplest GPS Script.  It simply reads the raw output of the GPS sensor on the GoPiGo or GrovePi and prints it. 
- grove_gps_data.py : Reads and parses the data for individual elements like the lat, long and other variables

*Note*:
You would only get good data when fix is 1 and you have 3 or more satellites in view. You might have to take the module near a window with access to open sky for good results
