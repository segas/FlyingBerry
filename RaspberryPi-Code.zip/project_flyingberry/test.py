import MySQLdb
mysql_connection_remote = MySQLdb.connect(host='88.84.20.245', user='flyingberry', passwd='Cherry@2', db='flyingberry')
