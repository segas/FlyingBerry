#!/usr/bin/python

####### LIBRARIES ########
from sense_hat import SenseHat
from datetime import datetime
import time
import MySQLdb
import math

# open a local database connection --> localhost
mysql_connection_local = MySQLdb.connect(host='localhost', user='root', passwd='Cherry@2', db='flyingberry')
cursor_local = mysql_connection_local.cursor()

# open a remote database connection --> segas.ch
mysql_connection_remote = MySQLdb.connect(host='segas.ch', user='flyingberry', passwd='Cherry@2', db='flyingberry')
cursor_remote = mysql_connection_remote.cursor()

######## MAIN PROGRAMM #########
sense = SenseHat()

while True:
	datetime  = time.strftime('%Y-%m-%d %H:%M:%S')
	humidity = sense.get_humidity()
	temperature = (sense.get_temperature_from_humidity()+sense.get_temperature_from_pressure()) / 2
	pressure = sense.get_pressure()
	altitude = hoehe = 7.99 * math.log(1.01325 / 0.975)	

	# MySQL Befehl in den Cursor laden
	cursor_local.execute("""INSERT INTO sensordata (datetime, temperature, humidity, pressure, altitude) VALUES (%s, %s, %s, %s, %s)""", (datetime, temperature, humidity, pressure, altitude))
	cursor_remote.execute("""INSERT INTO sensordata (datetime, temperature, humidity, pressure, altitude) VALUES (%s, %s, %s, %s, %s)""", (datetime, temperature, humidity, pressure, altitude))

	#MySQL Upload starten
	mysql_connection_local.commit()
	mysql_connection_remote.commit()

	time.sleep(2)

# close the connection
mysql_connection_local.close()
mysql_connection_remote.close()

	
