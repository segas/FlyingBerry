#!/usr/bin/python

####### LIBRARIES ########
from sense_hat import SenseHat
from datetime import datetime
import time
import MySQLdb
import math

# open a database connection
mysql_connection = MySQLdb.connect(host='localhost', user='root', passwd='Cherry@2', db='cherry')
cursor = mysql_connection.cursor()

######## MAIN PROGRAMM #########
sense = SenseHat()

while True:
	datetime  = time.strftime('%Y-%m-%d %H:%M:%S')
	humidity = sense.get_humidity()
	temperature = (sense.get_temperature_from_humidity()+sense.get_temperature_from_pressure()) / 2
	pressure = sense.get_pressure()
	altitude = hoehe = 7.99 * math.log(1.01325 / 0.975);
	
	# MySQL Befehl ausfuehren
	cursor.execute("""INSERT INTO sensordata (datetime, temperature, humidity, pressure, altitude) VALUES (%s, %s, %s, %s, %s)""", (datetime, temperature, humidity, pressure, altitude))
	#MySQL Upload starten
	mysql_connection.commit()
	
	time.sleep(2)

# close the connection
mysql_connection.close()

	
