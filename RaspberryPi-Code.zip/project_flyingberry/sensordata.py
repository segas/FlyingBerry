#!/usr/bin/python

####### Bibliotheken importieren ########
import time
import MySQLdb
import math
import hp206c # Barometersensor
import grove_i2c_temp_hum_mini #Temperatur und Feuchtigkeitssensor

# Die lokale Datenbankverbindung aufbauen --> localhost
mysql_connection_local = MySQLdb.connect(host='localhost', user='root', passwd='Cherry@2', db='flyingberry')
cursor_local = mysql_connection_local.cursor()

# Die Datenbankverbindung mit dem Webserver aufbauen --> segas.ch
mysql_connection_remote = MySQLdb.connect(host='88.84.20.245', user='flyingberry', passwd='Cherry@2', db='flyingberry')
cursor_remote = mysql_connection_remote.cursor()

# Barometer Sensor verbinden
h = hp206c.hp206c()
# Temperatur- und Feuchtigkeitssensor verbinden
t = grove_i2c_temp_hum_mini.th02()

######## HAUPTPROGRAMM #########

# Eine Endlosschleife initialisieren, welche laeuft solange man das Programm nicht abbricht
while True:
	try:
        	# Das heutige Datum und die derzeitige Zeit in die Variable datetime schreiben
        	#datetime  = time.strftime('%Y-%m-%d %H:%M:%S')
        	# Die derzeitige Feuchtigkeit auslesen und in die Variable humidity schreiben
        	humidity = t.getHumidity()
        	# Die derzeitige Temperatur auslesen --> Jedoch funktioniert das zurzeit nicht, weil sich das Board erhitzt
        	#temperature = (sense.get_temperature_from_humidity()+sense.get_temperature_from_pressure()) / 2
		temperature = h.ReadTemperature()
		# Der derzeitige Luftdruck auslesen und in die Variable pressure schreiben
        	pressure = h.ReadPressure()
        	# Die Hoehe aus dem Luftdruck ausrechnen und in die Variable altitude schreiben
        	altitude = h.ReadAltitude()

        	# MySQL Datenbank Befehl in den Cursor laden
		# Zuerst werden die Daten auf den lokalen Datenbankserver geladen
        	cursor_local.execute("""INSERT INTO sensordata (temperature, humidity, pressure, altitude) VALUES (%s, %s, %s, %s)""", (temperature, humidity, pressure, altitude))
		mysql_connection_local.commit()
		# Zweitens werden die Daten noch per Mobilem Netzwerk auf den Server SEGAS.CH geladen        
		cursor_remote.execute("""INSERT INTO sensordata (temperature, humidity, pressure, altitude) VALUES (%s, %s, %s, %s)""", (temperature, humidity, pressure, altitude))
		mysql_connection_remote.commit()

		# Output
		print "Temperatur: " + str(temperature) + " | Feuchtigkeit: " + str(humidity) + " | Luftdruck: " + str(pressure) + " | Hoehe ueber Meer: " + str(altitude)
	except IOError:
		print "IO Error"
	except:
		print "Other Error"
		
       	# Eine Pause von 2 Sekunden nach jedem Upload machen, damit wir die Datenbank nicht zumuellen
       	time.sleep(2)

# Die Verbindung mit der Datenbank schliessen
mysql_connection_local.close()
mysql_connection_remote.close()
